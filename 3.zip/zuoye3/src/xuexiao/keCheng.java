package xuexiao;

public class keCheng {
    void keChengMingCheng(int z){
        if(z == 101){
            System.out.println("高等数学");
        }else if(z == 102){
            System.out.println("JAVA");
        }else if(z == 0){
            System.out.println("无");
        }
    }
    void keChengXinXi(int q){
        if(q == 101){
            System.out.println("课程编号:101，课程名称:高等数学，301教室，上课时间:7:50，授课教师:张三");
        }else if(q == 102){
            System.out.println("课程编号:102，课程名称:JAVA，302教室，上课时间:13:30，授课教师:李四");
        }
    }
}
