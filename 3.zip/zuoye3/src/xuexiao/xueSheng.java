package xuexiao;

public class xueSheng extends renYuan{
    public void suoXuanKeCheng(){
        System.out.print("，所选课程:");
    }
}
